#include "headers.h"
#include "class.h"

int Rectangle::display()
{
	cout<<"Length : "<<length<<"  ";
	cout<<"Breadth : "<<breadth;
	return 0;
}
