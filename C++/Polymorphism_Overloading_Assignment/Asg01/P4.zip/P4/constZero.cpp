#include "headers.h"
#include "class.h"

Rectangle::Rectangle()
{
	cout<<" Zero Argument Constructor"<<endl;
	cout<<"Enter length "<<endl;
	cin>>length;
	cout<<"Enter Breadth "<<endl;
	cin>>breadth;
}
