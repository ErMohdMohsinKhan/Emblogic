#include "headers.h"
#include "classes.h"
Text::Text() : arg("")
{
}
