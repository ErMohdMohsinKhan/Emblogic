class Text
{
  private:
    string arg;
  public:
    Text(string); //open arg and open the file
   string contents(); //print the contents (print the string)
};
