#include"headers.h"
#include"classes.h"
Text::Text(string fn):arg(fn)
{
  cout<<__func__<<": Begin"<<endl;
  cout<<__func__<<": End"<<endl;
}
