#include "headers.h"
#include "class.h"

void Convert::display()
{
	cout<<number;
}

