#include "headers.h"
#include "class.h"

Convert::Convert()
{
	cout<<"Begin->Zero Argument Constructor"<<endl;
	number = 0;
	ptr = new int[10];
	
	cout<<"End->Zero Argument Constructor"<<endl;
}
