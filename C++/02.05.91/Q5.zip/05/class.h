class Convert
{
	private:
		int number;
		int *ptr;
	public:	
		Convert();
		void display();
		void trs();
		void binary(int);
		~Convert();
};
