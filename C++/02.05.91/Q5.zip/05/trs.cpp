#include "headers.h"
#include "class.h"
void Convert::trs()
{
	cout<<"Enter a number"<<endl;
	cin>>number;
	cout<<"Value in Decimal: "<<number<<endl;
	cout<<"value in Octal: "<<oct<<number<<endl;
	cout<<"value in Hex: "<<hex<<number<<endl;
	<<dec<<number;
	cout<<"Binary Equivalent of : "<<dec<<number<<"-->";
	binary(number);
}
